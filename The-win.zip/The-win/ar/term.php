<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>
<section class="py-0">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="bg-white p-4 text-center rounded-3">
					<h1>الشروط والاحكام</h1>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="pt-5 pb-5 my-5">
	<div class="container">
		<!-- Title -->
		<div class="row mb-4">
			<div class="col-lg-8">
				<h2 class="mb-3">الشروط والاحكام</h2>
				<p class="mb-2">
                    هو تطبيق تعليمى متطور مصمم لتمكين الطلاب في الجامعات الخاصة المختلفة مثل الجامعة العربية في الكويت ودول الخليج من تجربة تعليمية غنية مع مكتبة واسعة من مقاطع الفيديو التعليمية تم انشاء هذ الموقع المبتكر خصيصا لتلبية الاحتياجات الاكاديمية الفريدة للطلاب 
                </p>
                <p class="mb-2">
                    هو تطبيق تعليمى متطور مصمم لتمكين الطلاب في الجامعات الخاصة المختلفة مثل الجامعة العربية في الكويت ودول الخليج من تجربة تعليمية غنية مع مكتبة واسعة من مقاطع الفيديو التعليمية تم انشاء هذ الموقع المبتكر خصيصا لتلبية الاحتياجات الاكاديمية الفريدة للطلاب 
                </p>
			</div>
		</div>
		
	</div>
</section>


<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>