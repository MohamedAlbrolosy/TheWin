(function ($) {
    'use strict';

 $(".heart").on("click", function () {
        $(this).toggleClass("active");
    });
})(jQuery);