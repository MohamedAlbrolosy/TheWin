

<!-- Bootstrap JS -->

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Vendors -->
<script src="assets/js/glightbox.js"></script>
<script src="assets/js/tiny-slider-rtl.js"></script>
<?php 
if(isset($scripts) && count($scripts)){
    foreach($scripts as $script){
        echo " <script src=\"assets/js/{$script}.js\"></script>";
    }
}
?>
<!-- Template Functions -->
<script src="assets/js/functions.js"></script>
       


<script>
    const currentLoction = location.href;
    const menuItem = document.querySelectorAll('.navbar-collapse ul li a');
    const menuLength = menuItem.length
    for (let i = 0; i < menuLength; i++) {
        if (menuItem[i].href === currentLoction) {
            menuItem[i].className = "nav-link active"
        }
    }
</script>

<script>

    $(document).ready(function($) {
// Retrieve the object from storage
        var retrievedObject = JSON.parse(localStorage.getItem('country'));
        if (localStorage.getItem("country") === null) {
            $('#countriesModel').modal('show');
        } else {
           if (!retrievedObject.country_id){
               $('#countriesModel').modal('show');
           }
        }

        if (localStorage.getItem("country") !== null){
            if (retrievedObject.country_id){
                $('.countryItem').removeClass('active');
                $('#country_' + retrievedObject.country_id).addClass('active');
            }
        }
        $(document).on("click",".countryItem",function() {
            this.pageLoader = true;
            var country_id = $(this).data('area');
            $('.countryItem').removeClass('active');
            $('#country_' + country_id).addClass('active');
            axios.post("#",{country_id}).then(response => {
                console.log(response)
                if (response.data.url) {
                    var country_object = { 'country_id': country_id};
                    // Put the object into storage
                    localStorage.setItem('country', JSON.stringify(country_object));
                    window.location.replace(response.data.url);
                } else {
                    window.location.reload();
                }
            }).catch(error => {
                console.log(error)
                window.location.reload();
            });
        });
    });
</script>



</body>

</html>