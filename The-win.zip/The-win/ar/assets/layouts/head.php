<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>The Win || ذا ون </title>
    <meta name="description" content="">
    <meta name="author" content="" />
    <link rel="icon" href="images/logo.png">
    <!-- Plugins CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/glightbox.css">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-icons.css">
	<link rel="stylesheet" type="text/css" href="assets/css/tiny-slider.css">
     <?php 
    if(isset($styles) && count($styles)){
        foreach($styles as $style){
            echo "<link rel=\"stylesheet\" href=\"assets/css/{$style}.css\">";
        }
    }
    ?>
	<!-- Theme CSS -->
	<link rel="stylesheet" type="text/css" href="assets/css/style-rtl.css">
      <!--[if lt IE 9]>
          <script src="js/html5shiv.min.js"></script>
          <script src="js/respond.min.js"></script>
        <![endif]-->
</head>

<body>