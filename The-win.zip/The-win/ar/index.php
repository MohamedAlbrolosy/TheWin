<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>
<div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active" data-bs-interval="3000">
            <div class="slide-img">
                <img src="assets/images/01.jpeg" alt="" width="100%" class="bd-placeholder-img bd-placeholder-img-lg d-block w-100">
            </div>
        </div>
        <div class="carousel-item" data-bs-interval="3000">
            <div class="slide-img">
                <img src="assets/images/01.jpeg" alt="" width="100%" class="bd-placeholder-img bd-placeholder-img-lg d-block w-100">
            </div>
        </div>

    </div>
</div>


<section class="services">
    <div class="container text-center">
        <div class="row g-4">
            <!-- Item -->
            <div class="col-sm-12 col-md-4 ">
                <a href="materials.php" class="card card-body text-center position-relative">
                    <img src="assets/images/s2.jpg" alt="">
                </a>
            </div>

            <!-- Item -->
            <div class="col-sm-12 col-md-4 ">
                <a href="whats-groups.php" class="card card-body text-center position-relative">
                    <img src="assets/images/s3.jpg" alt="">
                </a>
            </div>

            <!-- Item -->
            <div class="col-sm-12 col-md-4 ">
                <a href="tma.php" class="card card-body  text-center position-relative">
                    <img src="assets/images/s1.jpg" alt="">
                </a>
            </div>

            <div class="col-sm-12 col-md-4 ">
                <a href="news.php" class="card card-body  text-center position-relative">
                    <img src="assets/images/s4.jpg" alt="">
                </a>
            </div>

            <div class="col-sm-12 col-md-4 ">
                <a href="info.php" class="card card-body  text-center position-relative">
                    <img src="assets/images/s5.jpg" alt="">
                </a>
            </div>

        </div>
    </div>
</section>




<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>