<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>


<section class="position-relative py-3 py-sm-4">
    <div class="container">
        <div class="row g-4 g-sm-5 justify-content-center">
            <div class="col-md-6 bg-white my-5 p-5">
                <!-- Title -->
                <span class="mb-0 fs-1">👋</span>
                <h1 class="fs-2">هل نسيت كلمة المرور؟</h1>

                <!-- Form START -->
                <form>
                    <!-- Email -->
                    <div class="mb-4">
                        <label for="exampleInputEmail1" class="form-label">البريد الالكتروني</label>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-light rounded-start border-0 text-secondary px-3"><i class="bi bi-envelope-fill"></i></span>
                            <input type="email" class="form-control border-0 bg-light rounded-end ps-1" placeholder="البريد الالكتروني" id="exampleInputEmail1">
                        </div>
                    </div>
                    <!-- Button -->
                    <div class="align-items-center mt-0">
                        <div class="d-grid">
                            <button class="btn btn-primary mb-0" type="button">ارسال</button>
                        </div>
                    </div>
                </form>
                <!-- Form END -->

            </div>
        </div>
    </div>
</section>


<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>