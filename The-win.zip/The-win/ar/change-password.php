<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>


<section class="pt-3 mt-3 mb-1">
	<div class="container mt-n4">
		<div class="row">
			<div class="col-12">
				<div class="col-12 col-xl-3 d-flex justify-content-between align-items-center">
					<a class="h6 mb-0 fw-bold d-xl-none" href="#">القائمة</a>
					<button class="btn btn-primary d-xl-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasSidebar" aria-controls="offcanvasSidebar">
						<i class="fas fa-sliders-h"></i>
					</button>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="py-5 mb-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-3">
                <div class="offcanvas-xl offcanvas-end" tabindex="-1" id="offcanvasSidebar">
                    <div class="offcanvas-header bg-light">
                        <h5 class="offcanvas-title" id="offcanvasNavbarLabel">حسابي</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#offcanvasSidebar" aria-label="Close"></button>
                    </div>

                    <div class="offcanvas-body p-3 p-xl-0">
                        <div class="bg-light border rounded-3 p-3 w-100">
                            <!-- Dashboard menu -->
                            <div class="list-group list-group-dark list-group-borderless collapse-list">
                                <a class="list-group-item" href="my-account.php"><i class="bi bi-ui-checks-grid fa-fw mx-2"></i> حسابي </a>
                                <a class="list-group-item" href="course-list.php"><i class="bi bi-basket fa-fw mx-2"></i>دوراتي</a>
                                <a class="list-group-item active" href="change-password.php"><i class="bi bi-gear fa-fw mx-2"></i>تغيير كلمة المرور</a>
                                <a class="list-group-item text-danger bg-danger-soft-hover" href="#"><i class="fas fa-sign-out-alt fa-fw mx-2"></i>تسجيل خروج</a>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-9">
                <div class="card border bg-white rounded-3">
                    <!-- Card header -->
                    <div class="card-header bg-white border-bottom">
                        <h3 class="card-header-title mb-0">تغيير كلمة المرور</h3>
                    </div>
                    <!-- Card body START -->
                    <div class="card-body">
                        <!-- Current password -->
                        <div class="mb-3">
                            <label class="form-label">كلمة المرور</label>
                            <input class="form-control" type="password" placeholder="كلمة المرور">
                        </div>
                        <!-- New password -->
                        <div class="mb-3">
                            <label class="form-label"> كلمة المرور الجديدة</label>
                            <div class="input-group">
                                <input class="form-control" type="password" placeholder="كلمة المرور الجديدة">
                                <span class="input-group-text p-0 bg-transparent">
                                    <i class="far fa-eye cursor-pointer p-2 w-40px"></i>
                                </span>
                            </div>
                            <div class="rounded mt-1" id="psw-strength"></div>
                        </div>
                        <!-- Confirm password -->
                        <div>
                            <label class="form-label">تأكيد كلمة المرور الجديدة</label>
                            <input class="form-control" type="password" placeholder="تأكيد كلمة المرور الجديدة">
                        </div>
                        <!-- Button -->
                        <div class="d-flex justify-content-start mt-4">
                            <button type="button" class="btn btn-primary mb-5">تغيير كلمة المرور</button>
                        </div>
                    </div>
                    <!-- Card body END -->
                </div>
            </div>
        </div>
    </div>
</section>



<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>