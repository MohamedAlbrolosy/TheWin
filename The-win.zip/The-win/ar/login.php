<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>


<section class="position-relative py-3 py-sm-4">
    <div class="container">
        <div class="row g-4 g-sm-5 justify-content-center">
            <div class="col-md-6 bg-white my-5 p-5">
                <!-- Title -->
                <span class="mb-0 fs-1">👋</span>
                <h1 class="fs-2">تسجيل دخول</h1>
                <p class="lead mb-4">يسعدني رؤيتك! يرجى تسجيل الدخول باستخدام حسابك.</p>

                <!-- Form START -->
                <form>
                    <!-- Email -->
                    <div class="mb-4">
                        <label for="exampleInputEmail1" class="form-label">البريد الالكتروني</label>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-light rounded-start border-0 text-secondary px-3"><i class="bi bi-envelope-fill"></i></span>
                            <input type="email" class="form-control border-0 bg-light rounded-end ps-1" placeholder="البريد الالكتروني" id="exampleInputEmail1">
                        </div>
                    </div>
                    <!-- Password -->
                    <div class="mb-4">
                        <label for="inputPassword5" class="form-label">كلمة المرور</label>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-light rounded-start border-0 text-secondary px-3"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control border-0 bg-light rounded-end ps-1" placeholder="كلمة المرور" id="inputPassword5">
                        </div>
                    </div>
                    <!-- Check box -->
                    <div class="mb-4 d-flex justify-content-between mb-4">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                            <label class="form-check-label" for="exampleCheck1">تذكرني</label>
                        </div>
                        <div class="text-primary-hover">
                            <a href="forgot-password.php" class="text-secondary">
                                <u>هل نسيت كلمة المرور؟</u>
                            </a>
                        </div>
                    </div>
                    <!-- Button -->
                    <div class="align-items-center mt-0">
                        <div class="d-grid">
                            <button class="btn btn-primary mb-0" type="button">تسجيل دخول</button>
                        </div>
                    </div>
                </form>
                <!-- Form END -->


                <!-- Sign up link -->
                <div class="mt-4 text-center">
                    <span>ليس لديك حساب؟ <a href="signup.php">سجل هنا</a></span>
                </div>
            </div>
        </div>
    </div>
</section>


<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>