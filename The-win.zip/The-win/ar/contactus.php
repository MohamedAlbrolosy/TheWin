<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>
<section class="py-0">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="bg-white p-4 text-center rounded-3">
					<h1 class="m-0">اتصل بنا</h1>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="position-relative py-3 py-sm-4">
    <div class="container">
        <div class="row g-4 g-sm-5 justify-content-center">

            <div class="col-lg-6 position-relative">
                <div class="bg-light  rounded-3 p-4 p-sm-5">
                    <!-- Title -->
                    <!-- Form START -->
                    <form class="row g-4 g-sm-3 mt-2 mb-0">
                        <!-- Name -->
                        <div class="col-12">
                            <label class="form-label">الاسم</label>
                            <input type="text" class="form-control">
                        </div>
                        <!-- Name -->
                        <div class="col-12">
                            <label class="form-label">رقم الهاتف</label>
                            <input type="text" class="form-control">
                        </div>
                        <!-- Email -->
                        <div class="col-12">
                            <label class="form-label">البريد الالكتروني</label>
                            <input type="email" class="form-control">
                        </div>
                        <div class="col-12">
                            <label class="form-label">الرسالة</label>
                            <textarea class="form-control" rows="4" placeholder=""></textarea>
                        </div>

                        <!-- Button -->
                        <div class="col-12 d-grid">
                            <button type="submit" class="btn btn-lg btn-primary mb-0">إرسال </button>
                        </div>
                    </form>
                    <!-- Form END -->
                </div>
            </div>
        </div>
    </div>
</section>


<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>