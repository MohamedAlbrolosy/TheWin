<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>
<section class="py-0">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="bg-white p-4 text-center rounded-3">
					<h1 class="m-0">المحتوى</h1>
				</div>
			</div>
		</div>
	</div>
</section>

<section class=" py-5 position-relative overflow-hidden">
    <div class="container position-relative py-3">
   
        <div class="row g-4 g-lg-5 justify-content-center">
            <!-- Item -->
            <div class="col-sm-12 col-xl-4">
                <div class="bg-body rounded-3 text-center p-4 position-relative">
                    <h5 class="mb-4 text-white">اشتراك ACT111 حضورى الميدتيرم</h5>
                    <p class="text-price mb-4">45.000 KWD </p>
                    <div class="btn-display gap-3 mx-auto">
                        <a href="material-details.php" class="btn btn-success text-white" type="button">عرض المحتوى</a>
                        <a href="#" class="btn btn-warning text-white" type="button">اضف الى الحقيبة</a>
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-xl-4">
                <div class="bg-body rounded-3 text-center p-4 position-relative">
                    <h5 class="mb-4 text-white">اشتراك ACT111 أونلاين الميدتيرم</h5>
                    <p class="text-price mb-4">35.000 KWD </p>
                    <div class="btn-display gap-3 mx-auto">
                        <a href="material-details.php" class="btn btn-success text-white" type="button">عرض المحتوى</a>
                        <a href="#" class="btn btn-warning text-white" type="button">اضف الى الحقيبة</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>