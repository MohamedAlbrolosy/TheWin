<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>
<section class="py-0">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="bg-white p-4 text-center rounded-3">
					<h1 class="m-0">The Bag</h1>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="py-5 my-5">
	<div class="container">
	
		<div class="row g-4 g-sm-5">
			<!-- Main content START -->
			<div class="col-lg-8 mb-4 mb-sm-0">
				<div class="card card-body p-4 shadow">
					<div class="table-responsive border-0 rounded-3">
						<table class="table align-middle p-4 mb-0">
							<tbody class="border-top-0">
								<tr>
									<td>
										<div class="d-lg-flex align-items-center">
											<div class="w-100px w-md-80px mb-2 mb-md-0 avatar-cart">
												<img src="assets/images/b1.jpg" class="rounded" alt="">
											</div>
											<h6 class="mb-0 ms-lg-3 mt-2 mt-lg-0">	
												<a href="material-details.php">In-person midterm B294</a>
											</h6>
										</div>
									</td>
									<td class="text-center">
										<h5 class="text-success mb-0">45.000 KWD</h5>
									</td>
									<td>
										<a href="#" class="btn btn-sm btn-success px-2 me-1 mb-1 mb-md-0"><i class="far fa-fw fa-edit"></i></a>
										<button class="btn btn-sm btn-danger px-2 mb-0"><i class="fas fa-fw fa-times"></i></button>
									</td>
								</tr>
								<tr>
									<td>
										<div class="d-lg-flex align-items-center">
											<!-- Image -->
											<div class="w-100px w-md-80px mb-2 mb-md-0 avatar-cart">
												<img src="assets/images/b1.jpg" class="rounded" alt="">
											</div>
											<!-- Title -->
											<h6 class="mb-0 ms-lg-3 mt-2 mt-lg-0">	
												<a href="material-details.php">In-person midterm B294</a>
											</h6>
										</div>
									</td>
									<td class="text-center">
										<h5 class="text-success mb-0">45.000 KWD</h5>
									</td>
									<td>
										<a href="#" class="btn btn-sm btn-success px-2 me-1 mb-1 mb-md-0"><i class="far fa-fw fa-edit"></i></a>
										<button class="btn btn-sm btn-danger px-2 mb-0"><i class="fas fa-fw fa-times"></i></button>
									</td>
								</tr>
							</tbody>
						</table>
					</div>

					<!-- Coupon input and button -->
					<div class="row g-3 mt-2">
						<div class="col-md-6">
							<div class="input-group">
								<input class="form-control form-control " placeholder="كود الخصم">
								<button type="button" class="btn btn-primary mx-1">Coupon</button>
							</div>
						</div>
						<!-- Update button -->
						<div class="col-md-6 text-md-end">
							<button class="btn btn-primary mb-0" disabled>Update the bag</button>
						</div>
					</div>	
				</div>
			</div>

			<div class="col-lg-4">
				<div class="card card-body p-4 shadow">
					<h4 class="mb-3">Bag Cost</h4>

					<!-- Price and detail -->
					<ul class="list-group list-group-borderless mb-2">
						<li class="list-group-item px-0 d-flex justify-content-between">
							<span class="h6 fw-light mb-0">Course price</span>
							<span class="h6 fw-light mb-0 fw-bold">45.000 KWD</span>
						</li>
						<li class="list-group-item px-0 d-flex justify-content-between">
							<span class="h6 fw-light mb-0"> Discount</span>
							<span class="text-danger">0KWD</span>
						</li>
						<li class="list-group-item px-0 d-flex justify-content-between">
							<span class="h5 mb-0">Total</span>
							<span class="h5 mb-0">90.000 KWD</span>
						</li>
					</ul>

					<div class="d-grid">
						<a href="#" class="btn btn-lg btn-success">Payment</a>
					</div>
				</div>
			</div>

		</div>
	</div>
</section>


<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>