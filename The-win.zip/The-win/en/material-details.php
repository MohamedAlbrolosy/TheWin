<?php
$styles = [
       'plyr',
    ];
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>
<section class="py-0">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="bg-white p-4 text-center rounded-3">
					<h1 class="m-0">Lesson details</h1>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="pb-0 py-lg-5">
    <div class="container">
        <div class="row">
            <!-- Right sidebar START -->
            <div class="col-lg-8 pt-5 pt-lg-0">
                <div class="row mb-5">
                    <div class="col-12 position-relative">
						<div class="video-player rounded-3">
							<video controls crossorigin="anonymous" playsinline poster="assets/images/01.jpeg" autoplay>
								<source src="assets/images/012.mp4" type="video/mp4" size="500">
							</video>
						</div>
					</div>
                </div>
            </div>
            <!-- Right sidebar END -->

            <!-- Main content START -->
            <div class="col-lg-4">
                <div class="card border rounded-2 p-0">
                    <h5 class="mb-4 text-block p-3"><b>ACT111 in-person midterm subscription</b></h5>
                    <!-- Tabs START -->
                    <div class="card-header border-bottom ">
                        <ul class="nav nav-pills nav-tabs-line py-0" id="course-pills-tab" role="tablist">
                            <!-- Tab item -->
                            <li class="nav-item" role="presentation">
                                <button class="nav-link mb-2 mb-md-0 fs-6 active" id="course-pills-tab-2" data-bs-toggle="pill" data-bs-target="#course-pills-2" type="button" role="tab" aria-controls="course-pills-2" aria-selected="false">Contents</button>
                            </li>
                            <!-- Tab item -->
                            <li class="nav-item" role="presentation">
                                <button class="nav-link mb-2 mb-md-0 fs-6 " id="course-pills-tab-1" data-bs-toggle="pill" data-bs-target="#course-pills-1" type="button" role="tab" aria-controls="course-pills-1" aria-selected="true">About the course</button>
                            </li>

                        </ul>
                    </div>
                    <!-- Tabs END -->

                    <!-- Tab contents START -->
                    <div class="card-body p-4">
                        <div class="tab-content pt-2" id="course-pills-tabContent">

                            <div class="tab-pane fade show active" id="course-pills-2" role="tabpanel" aria-labelledby="course-pills-tab-2">
                                <div class="hstack gap-3">
                                    <span class="h6 fw-light mb-0"><i class="bi bi-camera-video text-dark me-2"></i> 3 lessons</span>
                                    <span class="h6 fw-light mb-0"><i class="bi bi-clock text-dark me-2"></i> 8 Hours</span>
                                </div>
                                <hr> <!-- Divider -->
                                <!-- Course lecture -->
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="position-relative d-flex align-items-center">
                                        <a href="https://www.youtube.com/embed/tXHviS-4ygo" data-glightbox="" data-gallery="course-video" class="btn btn-info text-white btn-round btn-sm mb-0 stretched-link position-static">
                                            <i class="bi bi-lock me-0"></i>
                                        </a>
                                        <span class="d-inline-block text-truncate mx-2 mb-0 h6 fw-light w-100px w-sm-200px w-md-400px"> <b>Question one and two</b> </span>
                                    </div>
                                    <p class="mb-0">2m 10s</p>
                                </div>

                                <hr> <!-- Divider -->

                                <!-- Course lecture -->
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="position-relative d-flex align-items-center">
                                        <a href="https://www.youtube.com/embed/tXHviS-4ygo" data-glightbox="" data-gallery="course-video" class="btn  btn-round btn-info text-white btn-sm mb-0 stretched-link position-static">
                                            <i class="bi bi-lock me-0"></i>
                                        </a>
                                        <span class="d-inline-block text-truncate mx-2 mb-0 h6 fw-light w-100px w-sm-200px w-md-400px"><b> Question 3</b></span>
                                    </div>
                                    <p class="mb-0 text-truncate">15m 10s</p>
                                </div>

                                <hr> <!-- Divider -->

                                <!-- Course lecture -->
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="position-relative d-flex align-items-center">
                                        <a href="https://www.youtube.com/embed/tXHviS-4ygo" data-glightbox="" data-gallery="course-video" class="btn btn-info text-white btn-round btn-sm mb-0 stretched-link position-static">
                                            <i class="bi bi-play me-0"></i>
                                        </a>
                                        <span class="d-inline-block text-truncate mx-2 mb-0 h6 fw-light w-100px w-sm-200px w-md-400px">
                                            <b>Question 4</b></span>
                                    </div>
                                    <p class="mb-0">18m 10s</p>
                                </div>
                            </div>

                            <div class="tab-pane fade " id="course-pills-1" role="tabpanel" aria-labelledby="course-pills-tab-1">

                                <p class="mb-3">
                                    Midterm Ch1 & Ch2 <br />
                                    Final Ch3 & Ch4 & Ch5
                                </p>

                                <button type="button" class="btn btn-success">Join the group <i class="bi bi-whatsapp"></i> </button>

                                <!-- List content -->
                                <h5 class="mt-4 mb-3">What you will learn</h5>
                                <div class="row mb-3">
                                    <div class="col-md-12">
                                        <p class="mb-3">
                                            Midterm Ch1 & Ch2 <br />
                                            Final Ch3 & Ch4 & Ch5
                                        </p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>



<?php
$scripts = [
       'plyr',
    ];
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>