<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>

<section class="pt-3 mt-3 mb-1">
	<div class="container mt-n4">
		<div class="row">
			<div class="col-12">
				<div class="col-12 col-xl-3 d-flex justify-content-between align-items-center">
					<a class="h6 mb-0 fw-bold d-xl-none" href="#">Menu</a>
					<button class="btn btn-primary d-xl-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasSidebar" aria-controls="offcanvasSidebar">
						<i class="fas fa-sliders-h"></i>
					</button>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="py-5 mb-5">
    <div class="container">
        <div class="row">


            <div class="col-xl-3">
                <div class="offcanvas-xl offcanvas-end" tabindex="-1" id="offcanvasSidebar">
                    <div class="offcanvas-header bg-light">
                        <h5 class="offcanvas-title" id="offcanvasNavbarLabel">My Account</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#offcanvasSidebar" aria-label="Close"></button>
                    </div>

                    <div class="offcanvas-body p-3 p-xl-0">
                        <div class="bg-light border rounded-3 p-3 w-100">
                            <!-- Dashboard menu -->
                            <div class="list-group list-group-dark list-group-borderless collapse-list">
                                <a class="list-group-item" href="my-account.php"><i class="bi bi-ui-checks-grid fa-fw mx-2"></i> My Account </a>
                                <a class="list-group-item active" href="course-list.php"><i class="bi bi-basket fa-fw mx-2"></i>My Courses</a>
                                <a class="list-group-item" href="change-password.php"><i class="bi bi-gear fa-fw mx-2"></i>Change password</a>
                                <a class="list-group-item text-danger bg-danger-soft-hover" href="#"><i class="fas fa-sign-out-alt fa-fw mx-2"></i>Log Out</a>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-9">
                <div class="card bg-white border rounded-3">
                    <div class="card-header bg-white border-bottom">
                        <h3 class="card-header-title mb-0">My Courses</h3>
                    </div>
                    <div class="card-body">

                        <div class="row g-4">
                            <!-- Item -->
                            <div class="col-sm-12 col-md-3 ">
                                <a href="material-info.php" class="card card-body text-center position-relative">
                                    <img src="assets/images/b1.jpg" alt="">
                                </a>
                            </div>

                            <!-- Item -->
                            <div class="col-sm-12 col-md-3 ">
                                <a href="material-info.php" class="card card-body text-center position-relative">
                                    <img src="assets/images/b2.png" alt="">
                                </a>
                            </div>

                            <!-- Item -->
                            <div class="col-sm-12 col-md-3 ">
                                <a href="material-info.php" class="card card-body  text-center position-relative">
                                    <img src="assets/images/b3.png" alt="">
                                </a>
                            </div>

                            <div class="col-sm-12 col-md-3 ">
                                <a href="material-info.php" class="card card-body  text-center position-relative">
                                    <img src="assets/images/b1.jpg" alt="">
                                </a>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>