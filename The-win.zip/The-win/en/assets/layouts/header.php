<header class="navbar-light header-static navbar-sticky">
    <!-- Logo Nav START -->
    <nav class="navbar navbar-expand-xl">
        <div class="container">
            <!-- Logo START -->
            <a class="navbar-brand mx-0" href="index.php">
                <img class="light-mode-item navbar-brand-item" src="assets/images/logo-w.png" alt="logo">
            </a>
            <!-- Logo END -->

            <!-- Responsive navbar toggler -->
            <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-animation">
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
            </button>

            <!-- Main navbar START -->
            <div class="navbar-collapse collapse" id="navbarCollapse">

                <!-- Nav Search END -->
                <ul class="navbar-nav navbar-nav-scroll mx-auto">
                    <!-- Nav item 1 Demos -->
                    <li class="nav-item"> <a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"> <a class="nav-link" href="materials.php">Material</a> </li>
                    <li class="nav-item"> <a class="nav-link" href="whats-groups.php">WhatsApp Groups</a></li>
                    <li class="nav-item"> <a class="nav-link" href="tma.php"> Help with TMA </a> </li>
                    <li class="nav-item"> <a class="nav-link" href="news.php"> News </a> </li>
                    <li class="nav-item"> <a class="nav-link" href="info.php"> Information </a> </li>
                </ul>
            </div>
            <!-- Main navbar END -->


            <div class="mx-2 mx-md-3  d-none d-md-block">
                <a class="text-white" href="cart.php" >
                    <i class="bi bi-bag mx-2"></i> The Bag
                </a>
            </div>


            <div class="  d-none d-md-block">
                <a class="text-white" href="my-account.php" >
                    <i class="bi bi-person mx-2"></i> My Account
                </a>
            </div>
            
             <!-- Nav Search START for Deshtop-->
            <div class="nav nav-item dropdown nav-search ">
                <a class="nav-link" role="button" href="#" id="navSearch" data-bs-toggle="dropdown" aria-expanded="true" data-bs-auto-close="outside" data-bs-display="static">
                    <i class="bi bi-search text-white fs-4"> </i>
                </a>
                <div class="dropdown-menu dropdown-menu-end shadow p-2" aria-labelledby="navSearch" data-bs-popper="none">
                    <form class="input-group">
                        <input class="form-control" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-primary text-white mx-1" type="submit">Search</button>
                    </form>
                </div>
            </div>
            <!-- Nav Search END -->

        </div>
    </nav>
    <!-- Logo Nav END -->
</header>