<footer class="pt-0 bg-body position-relative">
    <div class="container">
        <div class="row mx-auto">
            <div class="col-lg-6 mx-auto text-center my-5">
                <!-- Social media button -->
                <ul class="list-inline mt-3 mb-3">
                    <li class="list-inline-item">
                        <a class="btn btn-light btn-sm shadow px-2" href="#">
                            <i class="fab fa-fw fa-facebook-f"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a class="btn btn-light btn-sm shadow px-2" href="#">
                            <i class="fab fa-fw fa-instagram"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a class="btn btn-light btn-sm shadow px-2" href="#">
                            <i class="fab fa-fw fa-twitter"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a class="btn btn-light btn-sm shadow px-2" href="#">
                            <i class="fab fa-fw fa-linkedin-in"></i>
                        </a>
                    </li>
                </ul>

                <ul class="nav justify-content-center text-primary-hover">
                    <li class="nav-item"><a class="nav-link text-white" href="#">Direct support</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="contactus.php">Contact us</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="aboutus.php">About US</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="term.php">Terms and Conditions</a></li>
                </ul>

                <!-- Bottom footer link -->
                <div class="mt-3 text-white">© The Win || Design and Programming
                    <a href="tocaan.com" class="text-reset btn-link text-primary-hover" target="_blank">Tocaan Company</a>
                </div>
            </div>
        </div>
    </div>
    <div class="mobile-nav navbar-collapse">
        <ul class="nav nav-fill">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="bi bi-house"></i>
                    <span>Home</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="cart.php" target="_blank">
                    <i class="bi bi-bag"></i>
                    <span>The Bag</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="materials.php">
                    <i class="bi bi-play-circle"></i>
                    <span>Socialist</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="my-account.php">
                    <i class="bi bi-person"></i>
                    <span>My Account</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="bi bi-translate"></i>
                    <span>العربية</span>
                </a>
            </li>
        </ul>
    </div>
</footer>



<div class="modal fade bd-example-modal-xl show" id="countriesModel" tabindex="-1" role="dialog" aria-modal="true" style="padding-right: 17px; display: block;">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header w-100 text-center">
                <h5 class="modal-title w-100 text-center">
                    Select Country
                </h5>
            </div>
            <div class="modal-body p-5">
                <div class="row  justify-content-center countries">
                    <div class="col-4 country">
                        <div class="countryItem" id="country_118" data-area="118">
                            <div class="row">
                                <div class="col-sm-12">
                                    <span class="flag">🇰🇼</span>
                                </div>
                                <div class="col-sm-12 ">
                                    <b>Kuwait</b>
                                </div>
                                <div class="col-sm-12">
                                    <span class="flags"><img src="assets/images/kuwait.png" /></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 country">
                        <div class="countryItem" id="country_195" data-area="195">
                            <div class="row">
                                <div class="col-sm-12">
                                    <span class="flag">🇸🇦</span>
                                </div>
                                <div class="col-sm-12">
                                    <b>Saudi Arabia</b>
                                </div>
                                <div class="col-md-12">
                                    <span class="flags"><img src="assets/images/saudi-arabia.png" /></span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
