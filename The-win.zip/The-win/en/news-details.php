<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>
<section class="py-0">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="bg-white p-4 text-center rounded-3">
					<h1>News details</h1>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="pt-5 pb-5">
    <div class="container">
        <div class="row g-0 g-lg-5">

            <!-- Left sidebar START -->
            <div class="col-lg-5">
                <div class="row">
                    <div class="col-md-6 col-lg-12">
                        <!-- Instructor image START -->
                        <div class="card shadow p-2 mb-4 text-center">
                            <div class="rounded-3">
                                <!-- Image -->
                                <img src="assets/images/news.png" class="card-img" alt="course image">
                            </div>

                        </div>
                    </div>

                </div>
            </div>
            <div class="col-lg-7">

                <!-- Title -->
                <h1 class="mb-0">Midterm Exam Schedule</h1>
                <p class="mt-2"><i class="bi bi-calendar-date"></i> 25/09/2024</p>
                <p class="mt-4">The midterm exam schedule for all subjects except English levels has not been released yet.</p>
                <div class="d-grid gap-2 col-4 mt-5">
                    <a href="assets/images/MGT112.pdf" class="btn btn-primary text-white" type="button" download>Open file</a>
                </div>
            </div>
            <!-- Main content END -->

        </div><!-- Row END -->
    </div>
</section>


<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>