<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>
<section class="py-0">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="bg-white p-4 text-center rounded-3">
                    <h1 class="m-0">عن ذا ون</h1>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="pt-5 pb-5 my-5">
    <div class="container">
        <!-- Title -->
        <div class="row mb-4">
            <div class="col-lg-8">
                <h2 class="mb-3">About The Win</h2>
                <p class="mb-2">
                    It is an advanced educational application designed to enable students in various private universities such as the Arab University in Kuwait and the Gulf States to have a rich educational experience with a wide library of educational videos. This innovative website was created specifically to meet the unique academic needs of students. </p>
                <p class="mb-2">
                    It is an advanced educational application designed to enable students in various private universities such as the Arab University in Kuwait and the Gulf States to have a rich educational experience with a wide library of educational videos. This innovative website was created specifically to meet the unique academic needs of students. </p>
            </div>
        </div>

    </div>
</section>


<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>