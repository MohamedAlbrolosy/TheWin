<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>
<section class="py-0">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="bg-white p-4 text-center rounded-3">
					<h1>The Win Services</h1>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="services">
	<div class="container text-center">
		

		<div class="row justify-content-center g-4">
			<!-- Item -->
			<div class="col-sm-6 col-md-3 ">
				<a href="material-list.php" class="card card-body text-center position-relative">
                    <img src="assets/images/m2.png" alt="">
				</a>
			</div>

			<!-- Item -->
			<div class="col-sm-6 col-md-3 ">
				<a href="material-list.php" class="card card-body text-center position-relative">
                    <img src="assets/images/m2.png" alt="">
				</a>
			</div>

			<!-- Item -->
			<div class="col-sm-6 col-md-3 ">
				<a href="material-list.php" class="card card-body text-center position-relative">
                    <img src="assets/images/m2.png" alt="">
				</a>
			</div>
            
          <!-- Item -->
			<div class="col-sm-6 col-md-3 ">
				<a href="material-list.php" class="card card-body text-center position-relative">
                    <img src="assets/images/m2.png" alt="">
				</a>
			</div>
            
           <!-- Item -->
			<div class="col-sm-6 col-md-3 ">
				<a href="material-list.php" class="card card-body text-center position-relative">
                    <img src="assets/images/m2.png" alt="">
				</a>
			</div>
           <!-- Item -->
			<div class="col-sm-6 col-md-3 ">
				<a href="material-list.php" class="card card-body text-center position-relative">
                    <img src="assets/images/m2.png" alt="">
				</a>
			</div>
            
           <!-- Item -->
			<div class="col-sm-6 col-md-3 ">
				<a href="material-list.php" class="card card-body text-center position-relative">
                    <img src="assets/images/m2.png" alt="">
				</a>
			</div>

			<!-- Item -->
			<div class="col-sm-6 col-md-3 ">
				<a href="material-list.php" class="card card-body text-center position-relative">
                    <img src="assets/images/m2.png" alt="">
				</a>
			</div>

		

		</div>
	</div>
</section>




<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>