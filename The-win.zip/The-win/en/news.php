<?php
     include('assets/layouts/head.php');
    include('assets/layouts/header.php');
?>
<section class="py-0">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="bg-white p-4 text-center rounded-3">
					<h1>News</h1>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="position-relative py-5">
    <div class="container">
        <div class="row g-4">
            <!-- Card item START -->
            <div class="col-sm-12 col-lg-4 col-xl-4">
                <div class="card bg-transparent">
                    <div class="overflow-hidden rounded-3">
                        <img src="assets/images/news.png" class="card-img" alt="course image">
                        <div class="bg-overlay bg-dark opacity-4"></div>
                    </div>

                    <!-- Card body -->
                    <div class="card-body bg-white">
                        <!-- Title -->
                        <h5 class="card-title"><a href="news-details.php">Midterm Exam Scheduleة</a></h5>
                        <p class="text-truncate-2">The midterm exam schedule for all subjects except English levels has not been released yet.</p>
                        <!-- Info -->
                        <div class="d-flex justify-content-between">
                            <span class="small"><i class="bi bi-calendar-date"></i> 25/09/2024</span>
                            <h6 class="mb-0"><a class="btn btn-primary fz-12" href="news-details.php">The details</a></h6>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-lg-4 col-xl-4">
                <div class="card bg-transparent">
                    <div class="overflow-hidden rounded-3">
                        <img src="assets/images/news.png" class="card-img" alt="course image">
                        <div class="bg-overlay bg-dark opacity-4"></div>
                    </div>

                    <!-- Card body -->
                    <div class="card-body bg-white">
                        <!-- Title -->
                        <h5 class="card-title"><a href="news-details.php">Midterm Exam Scheduleة</a></h5>
                        <p class="text-truncate-2">The midterm exam schedule for all subjects except English levels has not been released yet.</p>
                        <!-- Info -->
                        <div class="d-flex justify-content-between">
                            <span class="small"><i class="bi bi-calendar-date"></i> 25/09/2024</span>
                            <h6 class="mb-0"><a class="btn btn-primary fz-12" href="news-details.php">The details</a></h6>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-lg-4 col-xl-4">
                <div class="card bg-transparent">
                    <div class="overflow-hidden rounded-3">
                        <img src="assets/images/news.png" class="card-img" alt="course image">
                        <div class="bg-overlay bg-dark opacity-4"></div>
                    </div>

                    <!-- Card body -->
                    <div class="card-body bg-white">
                        <!-- Title -->
                        <h5 class="card-title"><a href="news-details.php">Midterm Exam Scheduleة</a></h5>
                        <p class="text-truncate-2">The midterm exam schedule for all subjects except English levels has not been released yet.</p>
                        <!-- Info -->
                        <div class="d-flex justify-content-between">
                            <span class="small"><i class="bi bi-calendar-date"></i> 25/09/2024</span>
                            <h6 class="mb-0"><a class="btn btn-primary fz-12" href="news-details.php">The details</a></h6>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- Row end -->

    </div>
</section>



<?php
    include('assets/layouts/footer.php');
    include('assets/layouts/scripts.php');
?>